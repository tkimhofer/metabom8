library(testthat)
library(metabom8)

test_check("metabom8")
