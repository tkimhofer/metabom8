## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = requireNamespace("nmrData", quietly = TRUE)
)

has_data <- requireNamespace("nmrData", quietly = TRUE)

## ----no-data-msg, echo = FALSE, results = "asis"------------------------------
# if (!has_data) {
#   message("The 'yourGitHubPackage' package is not installed. Please install it manually to run this example.")
# }else{
#   library(nmrdata)
# }

## ----load-pack, fig.show='hold', message=FALSE, warning=FALSE-----------------
# # load packages
# library(metabom8)
# 
# library(DT)
# library(htmlTable)
# library(dplyr)
# 

## ----read-in, fig.show='hold', message=FALSE, warning=FALSE-------------------
# # define path to NMR experiments
# path <- system.file("extdata/", package = "nmrdata"); print(path)
# 
# # import 1D NMRS data
# read1d_proc(path, exp_type=list(PULPROG='noesypr1d'))

## ----echo=FALSE, out.width='30%', include = TRUE------------------------------
# # create table
# df<-data.frame('Variable'=c('X', 'ppm', 'meta'),
#              'Description'=c('Matrix of NMR data (rows = spectra, columns = spectral variables (ppm))',
#                              'Array of chemical shift information (ppm)',
#                              'Dataframe of spectrometer metadata'))
# 
# datatable(df, rownames = FALSE, options = list(dom = 't'), colnames = c('Variable Name' = 1))
# 

## ----spec-overlay-single, fig.show='hold', fig.width = 7.2, fig.height = 4, message=FALSE, warning=FALSE----
# 
# # use 'spec' to plot a single spectrum, e.g., in row position 15:
# spec(X[15,], ppm, shift = range(ppm), interactive=FALSE)
# 
# # use 'matspec' to overlay spectra, in ppm range 0 to 10
# matspec(X, ppm, shift = c(1.2, 1.7), interactive=FALSE)

## ----spec-overlay-mlt, fig.show='hold', fig.width = 7, fig.height = 5, message=FALSE, warning=FALSE----
# # create run-order based on acquistion date
# meta$runOrder<-rank(as.POSIXct(meta$a_DATE))
# 
# # plot TSP signal
# specOverlay(X, ppm, shift=c(-0.05,0.05),
#     an=list( 'Facet'=meta$a_EXP, # facet
#              'RunOrder'=meta$runOrder, # colour
#              'Pulse Program'=meta$a_PULPROG) # linetype
#     )

## ----calibration, fig.show='hold', fig.width = 7.2, fig.height = 6, message=FALSE, warning=FALSE----
# # perform TSP calibration
# X_cal<-calibrate(X, ppm, type='tsp')
# 
# # plot TSP after calibration
# matspec(X_cal, ppm, shift=c(-0.1,0.1), interactive=FALSE)

## ----filter, fig.show='hold', fig.width = 7.2, fig.height = 4, message=FALSE, warning=FALSE----
# # Exclude calibration experiments
# idx<-grep('noe1d', meta$a_EXP)
# X_cal<-X_cal[idx,]
# meta<-meta[idx,]
# 
# # plot TSP signal
# specOverlay(X_cal, ppm, shift=c(-0.05,0.05),
#     an=list( 'Facet'=meta$a_EXP, # facet
#              'Receiver Gain'=meta$a_RG, # colour
#              'Pulse Program'=meta$a_PULPROG) # linetype
#     ) # linetype

## ----spec-qc-I, fig.show='hold', fig.width = 7.2, fig.height = 4, message=FALSE, warning=FALSE----
# # calculate quality control measures
# matspec(X_cal, ppm, shift=c(4.5,5), interactive=FALSE, main='Residual Water')
# matspec(X_cal, ppm, shift=c(9,11), interactive=FALSE, main='LowField Cap')
# matspec(X_cal, ppm, shift=c(-1,1), interactive=FALSE, main='UpField Cap')
# 
# 
# 

## ----excision, fig.show='hold', fig.width = 7.2, fig.height = 4, message=FALSE, warning=FALSE----
# # Indexing TSP region and upfield noise...
# idx_tsp<-get_idx(range=c(min(ppm), 0.5), ppm)
# # ... water region...
# idx_water<-get_idx(range=c(4.6, 5), ppm)
# # ... as well as downfield noise regions
# idx_noise<-get_idx(range=c(9.5, max(ppm)), ppm)
# 
# idx_rm<-c(idx_tsp, idx_water, idx_noise)
# 
# # Excision of TSP, residual water signal and noise regions
# X_cut<-X_cal[,-idx_rm]
# ppm<-ppm[-idx_rm]

## ----baseline, fig.show='hold', fig.width = 7.2, fig.height = 4, message=FALSE, warning=FALSE----
# # Baseline correction
# X_bl<-bline(X_cut)
# 
# # visual assessment
# Xcompare<-rbind(X_bl[1,], X_cut[1,])
# matspec(Xcompare, ppm, shift = c(7, 9), interactive=FALSE)
# matspec(Xcompare, ppm, shift = c(3,4), interactive=FALSE)

## ----normalisation, fig.show='hold', fig.width = 7.2, fig.height = 4, message=FALSE, warning=FALSE----
# # PQN normalisation
# X_pqn<-pqn(X_bl, add_DilF = 'dilf')
# 
# # Visualising the pqn dilution coefficient / scaling factor for each spectrum
# hist(dilf, xlab='PQN calculated dilution factor')

## ----visual-check, fig.show='hold', fig.width = 7.2, fig.height = 4, message=FALSE, warning=FALSE----
# matspec(X_pqn, ppm, shift = range(ppm), interactive=FALSE)
# matspec(X_pqn, ppm, shift = c(1.2, 1.7), interactive=FALSE)

## ----session-info, echo=FALSE-------------------------------------------------
# sessionInfo()

