## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = requireNamespace("nmrdata", quietly = TRUE)
)

has_data <- requireNamespace("nmrdata", quietly = TRUE)

## ----no-data-msg, echo = FALSE, results = "asis"------------------------------
if (!has_data) {
  message("The 'yourGitHubPackage' package is not installed. Please install it manually to run this example.")
}else{
  library(nmrdata)
}

## ----load-pack, message=FALSE, warning=FALSE----------------------------------
library(metabom8)

## ----fig.show='hold', fig.width = 7.2, fig.height = 4, message=FALSE, warning=FALSE----
# Load data
data(bariatric)

# Declare variables
Xn<-bariatric$X.pqn # PQN-normalised NMR data matrix
dim(Xn)

ppm<-bariatric$ppm     # chemical shift vector in ppm
length(ppm)

meta<-bariatric$meta   # spectrometer metadata
dim(meta)

an<-bariatric$an       # sample annotation
dim(an)


## ----fig.show='hold', fig.width = 7.2, fig.height = 4, message=FALSE, warning=FALSE----
spec(Xn[1,], ppm, shift = c(0,10)) # singe spectrum, interactive
matspec(Xn[1:10,], ppm, shift = c(0.8, 1))  # spectral overlay, interactive

## ----fig.show='hold', fig.width = 7.2, fig.height = 4, message=FALSE, warning=FALSE----
# Perform PCA
pca_model=pca(X=Xn, pc=2, scale='UV', center=TRUE)

## ----fig.show='hold', fig.width = 6, fig.height = 5, message=FALSE, warning=FALSE----
# define scores that should be labelled
idx<-which(pca_model@t[,1]>200 | pca_model@t[,2]>200 & an$Class=='RYGB') # PC 2 scores above 20 and in group RYGB

# construct label vector with mouse IDs
outliers <- rep("", nrow(an)); outliers[idx] <- an$ID[idx]

# Plot PCA scores, colour according to class, point shape according to time of sample collection and label outliers
plotscores(
  obj=pca_model, 
  pc=c(1,2), 
  an=list(
    Class=an$Class,         # point colour
    Timepoint=an$Timepoint, # point shape
    ID=outliers             # point label
  ),  
  title='PCA - Scores plot')

## ----fig.show='hold', fig.width = 7.2, fig.height = 4, message=FALSE, warning=FALSE----
# Focused loadings plot of PC 2 (aromatic region)
plotload(pca_model, pc = 2, shift = c(6, 9), type='backscaled')

## ----fig.show='hold', fig.width = 7.2, fig.height = 4, message=FALSE, warning=FALSE----
# Focused loadings plot of PC 2 (aromatic region)
specload(pca_model, 
         pc = 2, 
         shift = c(7.4, 7.6),
         an=list(
            facet=pca_model@t[,2]>0, 
            type='backscaled', 
            alp = 0.5, 
            title = 'Overlayed Spectra with Backscaled Loadings'
         )
)

## ----fig.show='hold', fig.width = 7.2, fig.height = 4, message=FALSE, warning=FALSE----
# Exclude pre-op group
idx<-an$Class!='Pre-op'
X<-Xn[idx,]
Y<-an$Class[idx]

# Train O-PLS model
opls.model<-opls(X,Y)

## ----echo=TRUE, eval=FALSE, message=FALSE, warning=FALSE----------------------
# summary(opls.model)

## ----fig.show='hold', fig.width = 6, fig.height = 5, message=FALSE, warning=FALSE----
permutatios<-opls_perm(opls.model, n = 10, plot = TRUE)

## ----fig.show='hold', fig.width = 6, fig.height = 5, message=FALSE, warning=FALSE----
distanceX<-dmodx(mod =opls.model, plot=TRUE)

## ----fig.show='hold', fig.width = 6, fig.height = 5, message=FALSE, warning=FALSE----
# Plot OPLS scores
plotscores(obj=opls.model, an=list(
  Surgery=an$Class[idx],          # colouring according to surgery type
  Timepoint=an$Timepoint[idx]),   # line type according to time point
  title='OPLS - Scores plot',     # plot title
  cv.scores = TRUE)               # visualise cross-validated scores

## ----fig.show='hold', fig.width = 6, fig.height = 5, message=FALSE, warning=FALSE----
plotload(opls.model, type="Statistical reconstruction", title = 'Stat. Reconstructed Loadings', shift = c(0.5, 9.5))

## ----fig.show='hold', fig.width = 6, fig.height = 5, message=FALSE, warning=FALSE----
plotload(opls.model, type = "backscaled", title = "Backscaled Loadings", shift = c(0.5, 9.5))

## ----fig.show='hold', fig.width = 7.2, fig.height = 5, message=FALSE, warning=FALSE----
specload(mod=opls.model, shift=c(7.3,7.45), an=list(
  facet=an$Class[idx]), 
  type='backscaled', 
  alp = 0.5, 
  title = 'Overlayed Spectra with Backscaled Loadings')

## ----fig.show='hold', fig.width = 7.2, fig.height = 5, message=FALSE, warning=FALSE----
# define driver peak (the ppm variable where all other spectral variables will be correlated to)
driver1<-7.834
# perform stocsy
stocsy_model<-stocsy(Xn, ppm, driver1) 
# zoom-in different plot regions
plotStocsy(stocsy_model, shift=c(7,8))
plotStocsy(stocsy_model, shift=c(3.9, 4))

## ----fig.show='hold', fig.width = 7.2, fig.height = 5, message=FALSE, warning=FALSE----
# define driver peak (the ppm variable where all other spectral variables will be correlated to)
poi<-7.874
sig = 0.02
subset_idc <- storm(Xn, ppm, idx.refSpec = 2, shift=c(poi-sig, poi+sig), b=10)

storm_sets = rep('not_matched', nrow(Xn))
storm_sets[subset_idc] = 'matched'
table(storm_sets)

specOverlay(Xn, ppm, shift = c(poi-sig, poi+sig), an=list(type=storm_sets))

# run stocsy or spike-in's with respective storm spectra/samples

## ----fig.show='hold', fig.width = 6, fig.height = 5, message=FALSE, warning=FALSE----
cat("> **Note:** This method provides only a preliminary compound suggestion. Further NMR validation is recommended.\n\n")

## ----citation, echo=FALSE, results='asis'-------------------------------------
citation("metabom8")

## ----session-info, echo=FALSE-------------------------------------------------
sessionInfo()

